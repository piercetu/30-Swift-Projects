//
//  PhotoCell.swift
//  PhotoScroll
//
//  Created by Pierce Tu on 4/11/20.
//  Copyright © 2020 Pierce Tu. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}
